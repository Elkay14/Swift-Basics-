// Variables


var str = "Hello, playground"

str = "Hello, World!"
str

var number = 10
number

number = 20
//// Constants 
let language = "swift"

//Naming COnventions 

let programingLanguage = "Objective-C"

//Rule #2 use Camal case 

let favoriteProgramingLanguage = "swift"