//Binary Operators

let height: Double = 12 // in feet
let width: Double  = 10 // feet

let area = height * width // area in sq feet 

//one square meter = 1 square foot / 10.764

let areaInMEters = area/10.764

//Equals Operator (Note: Different from assignmetn operator)

let string1 = "Hello!"
let string2 = "Hello!"
let string3 = "hello!"

string1 == string2
string1 == string3


//Not equal

string1 != string2
string1 != string3

"a" > "b"




