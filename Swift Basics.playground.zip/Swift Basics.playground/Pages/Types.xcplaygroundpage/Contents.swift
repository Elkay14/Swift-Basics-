// String Concatenation
let Country = "Unites States of America"
let State = "Ohio"
let City = "Akron"
let Street = "West Market Street"
let buildingNumber = 1776
let apartmentNumber = "Apt A"


let Address = Country + " " + State + " " + City
//let streetAdress = buildingNumer + Street + apartmentNumber <--Dose not compile

// String Interpolation

let interpolatedAddress = "\(Country), \(State), \(City)"
let interpolatedStreetAdress = "\(buildingNumber) \(Street) \(apartmentNumber)"

/*
 ---------
 Integers 
 ---------
 */

let favoriteProgrammingLanguage = "Swift"
let Year = 2014 // of type Int

/*
 ---------------------
Floating Point Numbers
 ---------------------
 */

var version = 3.0 // Of type Double 

/*
---------
Boolean
---------
 */

let isAwesome = true // of Type Bool = 1 or 0 (1True or 0False)

/*
 ---------
Type Safety
 ---------
 */

var someString = ""
//somestring = 12.0 

let bestPlayer: String = "Michael Jordan"

let averagePointsPerGame: Double = 30.1
let yearOfRetirement: Int = 2003
let hallOfFame: Bool = true



